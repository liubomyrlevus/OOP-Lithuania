<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/lubomirlevus/Downloads/Support 3/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>