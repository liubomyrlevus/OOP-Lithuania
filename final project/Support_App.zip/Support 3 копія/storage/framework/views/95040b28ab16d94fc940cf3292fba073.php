<?php echo e($slot); ?>

<?php /**PATH /Users/lubomirlevus/Downloads/Support 3/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>