<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Tickets')); ?>

            </h2>
            <?php if(auth()->user()->role === 'admin' || auth()->user()->role === 'staff' || auth()->user()->is_approved): ?>
                <a href="<?php echo e(route('tickets.create')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    + Create Ticket
                </a>
            <?php else: ?>
                <p class="text-gray-500 italic">Your account is pending admin approval.</p>
            <?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <?php if(session('success')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    
                    <form action="<?php echo e(route('tickets.index')); ?>" method="GET" class="mb-4 bg-gray-50 py-2 px-4 rounded-md border border-gray-200">
                        <?php $__currentLoopData = request()->except(['date_from', 'date_to', 'page']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="hidden" name="<?php echo e($key); ?>" value="<?php echo e($value); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex flex-wrap items-end gap-3">
                            <div>
                                <label class="block text-xs font-medium text-gray-700 mb-0.5">Date From</label>
                                <input type="date" name="date_from" value="<?php echo e(request('date_from')); ?>" class="rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 text-sm py-1 px-2">
                            </div>
                            <div>
                                <label class="block text-xs font-medium text-gray-700 mb-0.5">Date To</label>
                                <input type="date" name="date_to" value="<?php echo e(request('date_to')); ?>" class="rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 text-sm py-1 px-2">
                            </div>
                            <div class="flex gap-2">
                                <button type="submit" class="px-3 py-1 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 text-sm transition">Filter</button>
                                <a href="<?php echo e(route('tickets.index')); ?>" class="px-3 py-1 bg-white text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50 text-sm transition">Reset</a>
                            </div>
                        </div>
                    </form>

                    <div class="mb-4 flex flex-wrap items-center gap-5 bg-gray-50 py-2 px-4 rounded-md border border-gray-200 text-sm">
                        <div class="flex items-center gap-3">
                            <span class="font-bold text-gray-700">STATS:</span>
                            <span class="px-2 py-0.5 bg-yellow-100 text-yellow-800 rounded border border-yellow-200 shadow-sm">Pending: <?php echo e($pendingTasks); ?></span>
                            <span class="px-2 py-0.5 bg-green-100 text-green-800 rounded border border-green-200 shadow-sm">Resolved: <?php echo e($resolvedTasks); ?></span>
                        </div>

                        <?php if($categorySummary->isNotEmpty()): ?>
                            <span class="text-gray-300">|</span>
                            <div class="flex items-center gap-2">
                                <span class="font-bold text-gray-700 me-1">CATEGORY:</span>
                                <?php $__currentLoopData = $categorySummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $summary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="px-2 py-0.5 bg-white text-gray-700 rounded border border-gray-300 shadow-sm">
                                        <?php echo e($summary->category->name ?? 'Uncategorized'); ?>: <?php echo e($summary->total); ?>

                                    </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>

                        <?php if($performance && $performance->avg_time): ?>
                            <span class="text-gray-300">|</span>
                            <div class="flex items-center gap-2">
                                <span class="font-bold text-gray-700 me-1">TIME (hrs):</span>
                                <span class="px-2 py-0.5 bg-blue-50 text-blue-800 rounded border border-blue-200 shadow-sm">Avg: <?php echo e(round($performance->avg_time / 3600, 1)); ?></span>
                                <span class="px-2 py-0.5 bg-blue-50 text-blue-800 rounded border border-blue-200 shadow-sm">Min: <?php echo e(round($performance->min_time / 3600, 1)); ?></span>
                                <span class="px-2 py-0.5 bg-blue-50 text-blue-800 rounded border border-blue-200 shadow-sm">Max: <?php echo e(round($performance->max_time / 3600, 1)); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr>
                                <th class="border-b-2 py-2 px-4">ID</th>
                                <th class="border-b-2 py-2 px-4">Title</th>
                                
                                <th class="border-b-2 py-2 px-4 text-left relative" x-data="{ open: false }">
                                    <button @click="open = !open" @click.away="open = false" class="flex items-center gap-1 hover:text-indigo-600 focus:outline-none font-bold uppercase text-xs">
                                        Category
                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                                        <?php if(request('category')): ?> <span class="w-2 h-2 bg-indigo-500 rounded-full"></span> <?php endif; ?>
                                    </button>
                                    <div x-show="open" style="display: none;" class="absolute z-50 mt-1 w-48 bg-white rounded-md shadow-lg border border-gray-200 py-1 font-normal text-sm normal-case whitespace-nowrap">
                                        <a href="<?php echo e(request()->fullUrlWithQuery(['category' => null, 'page' => null])); ?>" class="block px-4 py-2 hover:bg-gray-100 <?php echo e(!request('category') ? 'font-bold text-indigo-600' : 'text-gray-700'); ?>">All Categories</a>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(request()->fullUrlWithQuery(['category' => $category->id, 'page' => null])); ?>" class="block px-4 py-2 hover:bg-gray-100 <?php echo e(request('category') == $category->id ? 'font-bold text-indigo-600' : 'text-gray-700'); ?>">
                                                <?php echo e($category->name); ?>

                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </th>

                                <th class="border-b-2 py-2 px-4 text-left relative" x-data="{ open: false }">
                                    <button @click="open = !open" @click.away="open = false" class="flex items-center gap-1 hover:text-indigo-600 focus:outline-none font-bold uppercase text-xs">
                                        Priority
                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                                        <?php if(request('priority')): ?> <span class="w-2 h-2 bg-indigo-500 rounded-full"></span> <?php endif; ?>
                                    </button>
                                    <div x-show="open" style="display: none;" class="absolute z-50 mt-1 w-40 bg-white rounded-md shadow-lg border border-gray-200 py-1 font-normal text-sm normal-case whitespace-nowrap">
                                        <a href="<?php echo e(request()->fullUrlWithQuery(['priority' => null, 'page' => null])); ?>" class="block px-4 py-2 hover:bg-gray-100 <?php echo e(!request('priority') ? 'font-bold text-indigo-600' : 'text-gray-700'); ?>">All Priorities</a>
                                        <?php $__currentLoopData = $priorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(request()->fullUrlWithQuery(['priority' => $priority->id, 'page' => null])); ?>" class="block px-4 py-2 hover:bg-gray-100 <?php echo e(request('priority') == $priority->id ? 'font-bold text-indigo-600' : 'text-gray-700'); ?>">
                                                <?php echo e($priority->name); ?>

                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </th>

                                <th class="border-b-2 py-2 px-4 text-left relative" x-data="{ open: false }">
                                    <button @click="open = !open" @click.away="open = false" class="flex items-center gap-1 hover:text-indigo-600 focus:outline-none font-bold uppercase text-xs">
                                        Status
                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                                        <?php if(request('status')): ?> <span class="w-2 h-2 bg-indigo-500 rounded-full"></span> <?php endif; ?>
                                    </button>
                                    <div x-show="open" style="display: none;" class="absolute z-50 mt-1 w-40 bg-white rounded-md shadow-lg border border-gray-200 py-1 font-normal text-sm normal-case whitespace-nowrap">
                                        <a href="<?php echo e(request()->fullUrlWithQuery(['status' => null, 'page' => null])); ?>" class="block px-4 py-2 hover:bg-gray-100 <?php echo e(!request('status') ? 'font-bold text-indigo-600' : 'text-gray-700'); ?>">All Statuses</a>
                                        <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(request()->fullUrlWithQuery(['status' => $status, 'page' => null])); ?>" class="block px-4 py-2 hover:bg-gray-100 <?php echo e(request('status') == $status ? 'font-bold text-indigo-600' : 'text-gray-700'); ?>">
                                                <?php echo e($status); ?>

                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </th>

                                <th class="border-b-2 py-2 px-4 text-left relative" x-data="{ open: false }">
                                    <button @click="open = !open" @click.away="open = false" class="flex items-center gap-1 hover:text-indigo-600 focus:outline-none font-bold uppercase text-xs">
                                        Client
                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                                        <?php if(request('client')): ?> <span class="w-2 h-2 bg-indigo-500 rounded-full"></span> <?php endif; ?>
                                    </button>
                                    <div x-show="open" style="display: none;" class="absolute z-50 mt-1 w-48 bg-white rounded-md shadow-lg border border-gray-200 py-1 font-normal text-sm normal-case whitespace-nowrap">
                                        <a href="<?php echo e(request()->fullUrlWithQuery(['client' => null, 'page' => null])); ?>" class="block px-4 py-2 hover:bg-gray-100 <?php echo e(!request('client') ? 'font-bold text-indigo-600' : 'text-gray-700'); ?>">All Clients</a>
                                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(request()->fullUrlWithQuery(['client' => $client->id, 'page' => null])); ?>" class="block px-4 py-2 hover:bg-gray-100 <?php echo e(request('client') == $client->id ? 'font-bold text-indigo-600' : 'text-gray-700'); ?>">
                                                <?php echo e($client->name); ?>

                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </th>

                                <th class="border-b-2 py-2 px-4 text-left relative" x-data="{ open: false }">
                                    <button @click="open = !open" @click.away="open = false" class="flex items-center gap-1 hover:text-indigo-600 focus:outline-none font-bold uppercase text-xs">
                                        Staff
                                        <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                                        <?php if(request('staff')): ?> <span class="w-2 h-2 bg-indigo-500 rounded-full"></span> <?php endif; ?>
                                    </button>
                                    <div x-show="open" style="display: none;" class="absolute right-0 z-50 mt-1 w-48 bg-white rounded-md shadow-lg border border-gray-200 py-1 font-normal text-sm normal-case whitespace-nowrap">
                                        <a href="<?php echo e(request()->fullUrlWithQuery(['staff' => null, 'page' => null])); ?>" class="block px-4 py-2 hover:bg-gray-100 <?php echo e(!request('staff') ? 'font-bold text-indigo-600' : 'text-gray-700'); ?>">All Staff</a>
                                        <a href="<?php echo e(request()->fullUrlWithQuery(['staff' => 'unassigned', 'page' => null])); ?>" class="block px-4 py-2 hover:bg-gray-100 <?php echo e(request('staff') == 'unassigned' ? 'font-bold text-indigo-600' : 'text-gray-700'); ?>">Unassigned</a>
                                        <?php $__currentLoopData = $staffMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(request()->fullUrlWithQuery(['staff' => $staff->id, 'page' => null])); ?>" class="block px-4 py-2 hover:bg-gray-100 <?php echo e(request('staff') == $staff->id ? 'font-bold text-indigo-600' : 'text-gray-700'); ?>">
                                                <?php echo e($staff->name); ?>

                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-100">
                                    <td class="border-b py-2 px-4"><?php echo e($ticket->id); ?></td>
                                    <td class="border-b py-2 px-4 font-bold">
                                        <a href="<?php echo e(route('tickets.show', $ticket)); ?>" class="text-blue-600 hover:text-blue-800 hover:underline">
                                            <?php echo e($ticket->title); ?>

                                        </a>
                                    </td>
                                    <td class="border-b py-2 px-4"><?php echo e($ticket->category->name); ?></td>
                                    <td class="border-b py-2 px-4"><?php echo e($ticket->priority->name); ?></td>
                                    
                                    <td class="border-b py-2 px-4">
                                        <?php if(auth()->user()->role === 'admin' || auth()->user()->role === 'staff'): ?>
                                            <form action="<?php echo e(route('tickets.updateStatus', $ticket)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <select name="status" onchange="this.form.submit()" class="text-sm border-gray-300 rounded-md py-1">
                                                    <option value="New" <?php echo e($ticket->status == 'New' ? 'selected' : ''); ?>>New</option>
                                                    <option value="In Progress" <?php echo e($ticket->status == 'In Progress' ? 'selected' : ''); ?>>In Progress</option>
                                                    <option value="Resolved" <?php echo e($ticket->status == 'Resolved' ? 'selected' : ''); ?>>Resolved</option>
                                                    <option value="Rejected" <?php echo e($ticket->status == 'Rejected' ? 'selected' : ''); ?>>Rejected</option>
                                                    <option value="Closed" <?php echo e($ticket->status == 'Closed' ? 'selected' : ''); ?>>Closed</option>
                                                </select>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-sm font-semibold text-gray-700"><?php echo e($ticket->status); ?></span>
                                        <?php endif; ?>
                                    </td>
                                    
                                    <td class="border-b py-2 px-4"><?php echo e($ticket->client?->name ?? 'Deleted user'); ?></td>
                                    
                                    <td class="border-b py-2 px-4 text-sm">
                                        <?php echo e($ticket->staff?->name ?? 'Not assigned / Staff deleted'); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="border-b py-4 px-4 text-center text-gray-500">
                                        No tickets found matching your filters.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                    <div class="mt-4">
                        <?php echo e($tickets->links()); ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Support\resources\views/tickets/index.blade.php ENDPATH**/ ?>