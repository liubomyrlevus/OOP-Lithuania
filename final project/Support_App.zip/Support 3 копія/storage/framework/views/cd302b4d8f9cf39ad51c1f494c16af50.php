<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Ticket #<?php echo e($ticket->id); ?> Details
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg flex flex-col md:flex-row">
                
                <div class="p-6 text-gray-900 w-full md:w-[55%] border-r border-gray-200">
                    <h3 class="text-2xl font-bold mb-2"><?php echo e($ticket->title); ?></h3>
                    
                    <div class="bg-gray-50 p-4 rounded-md border border-gray-200 min-h-[150px] mb-6">
                        <?php echo e($ticket->description); ?>

                    </div>

                    <h4 class="text-lg font-bold border-b pb-2 mb-4">Comments</h4>
                    
                    <div class="space-y-4 mb-6">
                        <?php $__empty_1 = true; $__currentLoopData = $ticket->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="bg-gray-50 p-4 rounded-md border border-gray-200">
                                <div class="flex justify-between text-xs text-gray-500 mb-2 border-b pb-1">
                                    <span class="font-bold text-gray-700"><?php echo e($comment->user->name); ?> (<?php echo e(ucfirst($comment->user->role)); ?>)</span>
                                    <span><?php echo e($comment->created_at->format('M d, Y H:i')); ?></span>
                                </div>
                                <p class="text-sm whitespace-pre-wrap"><?php echo e($comment->content); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-sm text-gray-500 italic">No comments yet.</p>
                        <?php endif; ?>
                    </div>

                    <form action="<?php echo e(route('comments.store', $ticket)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <textarea name="content" required class="w-full rounded-md border-gray-300 text-sm mb-2 focus:border-blue-500 focus:ring-blue-500" rows="3" placeholder="Write a comment..."></textarea>
                        <button type="submit" class="mt-3 inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-600 active:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition ease-in-out duration-150 shadow-sm">
                            Post Comment
                        </button>
                    </form>
                </div>

                <div class="p-6 bg-gray-50 w-full md:w-[45%] flex flex-col">
                    <h4 class="font-bold text-lg mb-4 border-b pb-2">Ticket Control</h4>

                    <?php if(auth()->user()->role === 'admin'): ?>
                        <div class="mb-6 space-y-4 p-4 bg-white rounded-md border border-gray-200 shadow-sm">
                            <h5 class="text-xs font-bold text-gray-400 uppercase tracking-wider">Admin Override</h5>
                            <form action="<?php echo e(route('tickets.update', $ticket)); ?>" method="POST">
                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                <label class="block text-sm font-bold text-gray-700 mb-1">Status:</label>
                                <select name="status" onchange="this.form.submit();" class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 text-sm">
                                    <option value="New" <?php echo e($ticket->status == 'New' ? 'selected' : ''); ?>>New</option>
                                    <option value="In Progress" <?php echo e($ticket->status == 'In Progress' ? 'selected' : ''); ?>>In Progress</option>
                                    <option value="Resolved" <?php echo e($ticket->status == 'Resolved' ? 'selected' : ''); ?>>Resolved</option>
                                    <option value="Rejected" <?php echo e($ticket->status == 'Rejected' ? 'selected' : ''); ?>>Rejected</option>
                                    <option value="Closed" <?php echo e($ticket->status == 'Closed' ? 'selected' : ''); ?>>Closed</option>
                                </select>
                            </form>
                            
                            <form action="<?php echo e(route('tickets.update', $ticket)); ?>" method="POST">
                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                <label class="block text-sm font-bold text-gray-700 mb-1">Assignee:</label>
                                <select name="staff_id" onchange="this.form.submit();" class="block w-full rounded-md border-gray-300 text-sm focus:border-blue-500 focus:ring-blue-500 shadow-sm">
                                    <option value="">-- Unassigned --</option>
                                    <?php $__currentLoopData = $staffMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($staff->id); ?>" <?php echo e($ticket->staff_id == $staff->id ? 'selected' : ''); ?>><?php echo e($staff->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </form>
                        </div>
                    <?php endif; ?>

                    <?php if(auth()->user()->role !== 'admin'): ?>
                        <div class="mb-6 flex justify-between items-center bg-white p-3 rounded-md border border-gray-200 shadow-sm">
                            <div>
                                <span class="block text-xs text-gray-500 uppercase tracking-wider font-bold mb-1">Status</span>
                                <?php
                                    $statusColors = [
                                        'New' => 'bg-green-100 text-green-800',
                                        'In Progress' => 'bg-blue-100 text-blue-800',
                                        'Resolved' => 'bg-purple-100 text-purple-800',
                                        'Rejected' => 'bg-red-100 text-red-800',
                                        'Closed' => 'bg-gray-200 text-gray-800',
                                    ];
                                    $colorClass = $statusColors[$ticket->status] ?? 'bg-gray-100 text-gray-800';
                                ?>
                                <span class="<?php echo e($colorClass); ?> px-2.5 py-0.5 rounded text-sm font-bold shadow-sm"><?php echo e($ticket->status); ?></span>
                            </div>
                            <div class="text-right">
                                <span class="block text-xs text-gray-500 uppercase tracking-wider font-bold mb-1">Assignee</span>
                                <span class="text-sm font-bold <?php echo e($ticket->staff_id === auth()->id() ? 'text-indigo-600' : 'text-gray-700'); ?>">
                                    <?php echo e($ticket->staff ? $ticket->staff->name : 'Unassigned'); ?>

                                </span>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if(auth()->user()->role === 'client' && in_array($ticket->status, ['Resolved', 'Rejected'])): ?>
                        <div class="mt-2 p-4 bg-yellow-50 border border-yellow-200 rounded-md mb-6 shadow-sm">
                            <p class="text-sm text-yellow-800 font-bold mb-3">
                                The ticket is currently <?php echo e($ticket->status); ?>. Please provide your feedback and select an action:
                            </p>
                            
                            <form action="<?php echo e(route('tickets.update', $ticket)); ?>" method="POST" class="space-y-3">
                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                <textarea name="client_comment" required class="w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-yellow-500 focus:ring-yellow-500" rows="3" placeholder="Explain why you are closing or reopening this ticket..."></textarea>
                                
                                <div class="flex gap-2">
                                    <button type="submit" name="client_action" value="In Progress" class="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-2 rounded transition shadow-sm text-sm">
                                        Reopen
                                    </button>
                                    <button type="submit" name="client_action" value="Closed" class="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-2 rounded transition shadow-sm text-sm">
                                        Accept & Close
                                    </button>
                                </div>
                            </form>
                        </div>
                    <?php endif; ?>

                    <?php if(auth()->user()->role !== 'client'): ?>
                        <?php if($ticket->staff_id === auth()->id()): ?>
                            <div class="mb-4">
                                <h5 class="font-bold text-gray-800 mb-2">My Quick Actions</h5>
                                <p class="text-xs text-gray-500 mb-3">Add a required comment and select an action to process this ticket.</p>
                                
                                <form action="<?php echo e(route('tickets.update', $ticket)); ?>" method="POST" class="space-y-3">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                    <textarea name="action_comment" required class="w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-blue-500 focus:ring-blue-500" rows="3" placeholder="Explain your decision..."></textarea>
                                    
                                    <div class="flex flex-col gap-2">
                                        <div class="flex gap-2">
                                            <button type="submit" name="quick_action" value="release" class="flex-1 bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-2 px-2 rounded transition shadow-sm text-sm">
                                                Release
                                            </button>
                                            <button type="submit" name="quick_action" value="Rejected" class="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-2 rounded transition shadow-sm text-sm">
                                                Reject
                                            </button>
                                        </div>
                                        <button type="submit" name="quick_action" value="Resolved" class="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded transition shadow-sm text-sm">
                                            Resolve Ticket
                                        </button>
                                    </div>
                                </form>
                            </div>
                        <?php elseif(is_null($ticket->staff_id)): ?>
                            <div class="mb-4">
                                <form action="<?php echo e(route('tickets.update', $ticket)); ?>" method="POST">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                    <input type="hidden" name="staff_id" value="<?php echo e(auth()->id()); ?>">
                                    <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded transition shadow-sm">
                                        Claim Ticket
                                    </button>
                                </form>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>

                    <div class="flex-grow"></div>

                    <div class="mt-6 pt-4 border-t border-gray-200 flex justify-center">
                        <a href="<?php echo e(route('tickets.index')); ?>" 
                        class="inline-flex items-center px-6 py-2 bg-gray-800 border border-transparent rounded-md text-white hover:bg-blue-600 focus:bg-blue-600 active:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors ease-in-out duration-200 shadow-sm"
                        title="Повернутися до списку">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.7" d="M7 11L3 7l4-4"></path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.7" d="M12 21 C 24 20, 23 7, 3 7"></path>
                            </svg>
                        </a>
                    </div>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /Users/lubomirlevus/Downloads/Support 3/resources/views/tickets/show.blade.php ENDPATH**/ ?>